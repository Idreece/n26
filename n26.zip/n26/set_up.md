# Set Up instructions

### Please set up your virtual environment with python version 3.10.0 which is what I have used in this project

### - I have created a requirements.txt file from the virtual environment I used for this project and note I used python version 3.10.0, I believe you will run into errors with auto arima in later python versions, please set up your environment with this set up if you wish to replicate my code 

### once you have activated your virtual environment you can load required packages with either 
### - pip install -r requirements.txt
### - conda install -r requirements.txt (if you are using anaconda or miniconda)
